﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static bazaprojekt.Form1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace bazaprojekt
{
    public partial class rezervacija : Form
    {
        string ID;
        string vremena;
        string prostorija;
        string ponavljanje;

        string[] popisvremena;
        string[] popisprostorija;
        string[] popisponavljanja;

        string theDate;


        public rezervacija( string IDf, string vremenaf, string prostorijaf, string ponavljanjef)
        {
            InitializeComponent();
            ID = IDf;
            vremena = vremenaf;
            prostorija = prostorijaf;   
            ponavljanje = ponavljanjef;
            MessageBox.Show("" + ID + " " + " " + vremena + " " + prostorija + " " + ponavljanje);

        }

        
        private void rezervacija_Load(object sender, EventArgs e)
        {
            popisvremena = vremena.Split(new string[] { ";" }, StringSplitOptions.None);
            popisprostorija = prostorija.Split(new string[] { ";" }, StringSplitOptions.None);
            popisponavljanja = ponavljanje.Split(new string[] { ";" }, StringSplitOptions.None);

            foreach (string s in popisvremena) {
              //  comboBox1.Items.Add(s);
                    }
            foreach (string s in popisprostorija)
            {
                comboBox2.Items.Add(s);
            }
            foreach (string s in popisponavljanja)
            {
                comboBox3.Items.Add(s);
            }
            foreach (string s in popisvremena)
            {
                comboBox4.Items.Add(s);
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            theDate  = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            //string pocetno=comboBox1.Text;
            string zavrsno=comboBox4.Text;
            string ucionica=comboBox2.Text;
            SqlCommand naredba;
            SqlDataReader dataReader2;
            SqlCommand naredba2;

/*
            Spajanje cnn = Spajanje.Instance;
            string sql2 = "select * from Rezervacije";
            string provjeradatuma;
            string provpocetnog;
            string provzavrsnog;
            string provuc;
            bool zauzeto=false;
            cnn.Open();
            naredba2 = new SqlCommand(sql2, cnn.GetConnection());
            dataReader2 = naredba2.ExecuteReader();
            while (dataReader2.Read())
            {
                provjeradatuma = dataReader2.GetValue(1).ToString();
                provpocetnog = dataReader2.GetValue(3).ToString();
                provzavrsnog = dataReader2.GetValue(4).ToString();
                provuc=dataReader2.GetValue(5).ToString();
                if (provjeradatuma.Contains(theDate) && provpocetnog.Contains(pocetno) && provzavrsnog.Contains(zavrsno) && provuc.Contains(ucionica))
                {
                    zauzeto=true;
                }

            }
            cnn.Close();
            naredba2.Dispose();
*/
           // MessageBox.Show("" + theDate + "   " + ID + "   " + comboBox1.SelectedIndex.ToString() + "   " + comboBox4.SelectedIndex.ToString() + "   " + comboBox2.SelectedIndex.ToString() + "   " + comboBox3.SelectedIndex.ToString());
            /*
            if (zauzeto == false)
            {
                Spajanje cnn2 = Spajanje.Instance;
                cnn2.Open();
                string com1 = comboBox1.SelectedIndex.ToString();
                MessageBox.Show("" + com1);
                SqlDataAdapter adapter = new SqlDataAdapter();
                string sql = "";
                sql = "Insert into Rezervacije (Datum,UserID,PocetakID,KrajID,ProstorijaID,PonavljanjeID,Aktivno) values ('" + theDate + "','" + ID + "','" + (int.Parse(comboBox1.SelectedIndex.ToString())+4).ToString() + "','" + (int.Parse(comboBox4.SelectedIndex.ToString()) + 1).ToString() + "','" + (comboBox2.SelectedIndex + 1).ToString() + "','" +( comboBox3.SelectedIndex + 1).ToString() + "',1); ";
                naredba = new SqlCommand(sql, cnn2.GetConnection());
                adapter.InsertCommand = new SqlCommand(sql, cnn.GetConnection());
                adapter.InsertCommand.ExecuteNonQuery();
                cnn.Close();

            }
          */


           

        }
    }
}
