﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bazaprojekt
{
    public partial class glavni_menu : Form
    {
        public glavni_menu()
        {
            InitializeComponent();
        }
    }
}
